const express = require('express');
const router = express.Router();
const adminController = require('../controllers/administratorController');

router.post('/register', adminController.register);
router.post('/login', adminController.login);
router.get('/:adminId', adminController.getAdminById);
router.put('/:adminId', adminController.updateAdmin);
router.put('/:adminId/change-password', adminController.changePassword);

module.exports = router;
