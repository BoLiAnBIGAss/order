const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// 生成订单
router.post('/create', orderController.createOrder);

// 根据手机号按时间倒序查询所有订单
router.get('/byPhoneNumber/:phoneNumber', orderController.getOrdersByPhoneNumber);

// 删除订单
router.delete('/:orderId', orderController.deleteOrder);

// 按时间倒序查看所有订单
router.get('/all', orderController.getAllOrders);

// 修改订单状态
router.put('/:orderId/status', orderController.updateOrderStatus);

module.exports = router;
