const express = require('express');
const router = express.Router();
const dishPortionController = require('../controllers/dishPortionController');

router.get('/dish/:dishName', dishPortionController.getDishPortionsByDish);
router.post('/', dishPortionController.createDishPortion);
router.delete('/:portionId', dishPortionController.deleteDishPortion);

module.exports = router;
