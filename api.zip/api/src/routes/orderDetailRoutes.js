const express = require('express');
const router = express.Router();
const orderDetailController = require('../controllers/orderDetailController');

// 生成订单详情
router.post('/create', orderDetailController.createOrderDetail);

// 删除订单详情
router.delete('/:orderDetailId', orderDetailController.deleteOrderDetail);

module.exports = router;
