const express = require('express');
const router = express.Router();
const tableController = require('../controllers/tableController');

// 生成餐桌信息（包括二维码）并保存至服务器与数据库，返回给客户端
router.post('/create', tableController.createTable);

// 删除餐桌信息（包括对应的二维码文件）
router.delete('/:tableId', tableController.deleteTable);

module.exports = router;
