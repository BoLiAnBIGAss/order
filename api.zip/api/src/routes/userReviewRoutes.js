const express = require('express');
const router = express.Router();
const userReviewController = require('../controllers/userReviewController');

// 根据菜品查看评论并按评分从高到低展示
router.get('/reviews/:dishId', userReviewController.getReviewsByDish);

// 创建用户评价
router.post('/create-review', userReviewController.createReview);

module.exports = router;
