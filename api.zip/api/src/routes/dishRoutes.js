const express = require('express');
const router = express.Router();
const dishController = require('../controllers/dishController');

router.get('/', dishController.getAllDishes);
router.get('/category/:categoryName', dishController.getDishesByCategory);
router.get('/popular', dishController.getPopularDishes);
router.post('/', dishController.createDish);
router.put('/:dishId', dishController.updateDish);
router.delete('/:dishId', dishController.deleteDish);

module.exports = router;
