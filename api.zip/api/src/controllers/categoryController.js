const Category = require('../models/DishCategory');
const Dish = require('../models/Dish');
const { Op } = require('sequelize');

//创建分类
exports.createCategory = async (req, res) => {
    try {
        const { categoryName } = req.body;

        // 检查分类名称是否已存在
        const existingCategory = await Category.findOne({ where: { categoryName } });
        if (existingCategory) {
            return res.status(400).json({ message: '分类名称冲突！' });
        }

        const newCategory = await Category.create({ categoryName });
        res.status(201).json(newCategory);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
//获取所有分类信息
exports.getAllCategories = async (req, res) => {
    try {
        const categories = await Category.findAll();
        res.json(categories);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getCategoryById = async (req, res) => {
    try {
        const { categoryId } = req.params;
        const category = await Category.findByPk(categoryId);
        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }
        res.json(category);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
//修改分类
exports.updateCategory = async (req, res) => {
    try {
        const { categoryId } = req.params;
        const { categoryName } = req.body;

        // 检查分类名称是否已存在
        const existingCategory = await Category.findOne({ where: { categoryName, id: { [Op.ne]: categoryId } } });
        if (existingCategory) {
            return res.status(400).json({ message: '分类名称冲突！' });
        }

        const [updated] = await Category.update({ categoryName }, { where: { id: categoryId } });
        if (updated) {
            res.json({ message: '修改成功！' });
        } else {
            res.status(404).json({ message: 'Category not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
// 删除分类
exports.deleteCategory = async (req, res) => {
    try {
        const { categoryId } = req.params;

        // 检查分类是否存在
        const category = await Category.findByPk(categoryId);
        if (!category) {
            return res.status(404).json({ message: 'Category not found' });
        }

        // 检查该分类下是否存在菜品
        const dishes = await Dish.findAll({ where: { categoryId } });
        if (dishes.length > 0) {
            // 存在菜品，先删除这些菜品
            await Dish.destroy({ where: { categoryId } });
        }

        // 删除分类
        await Category.destroy({ where: { id: categoryId } });

        res.json({ message: '删除成功！' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};