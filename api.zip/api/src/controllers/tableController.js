// controllers/tableController.js

const Table = require('../models/Table');
const qrCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// 生成餐桌信息（包括二维码）并保存至服务器与数据库，返回给客户端
exports.createTable = async (req, res) => {
    try {
        const { tableName } = req.body;

        // 创建餐桌
        const newTable = await Table.create({ tableName });

        // 构建指向小程序的链接，这里假设小程序的路径为 '/pages/index/index'
        const miniProgramUrl = 'https://your-mini-program-url.com/pages/index/index';

        // 构建包含餐桌信息的链接
        const tableInfoUrl = `${miniProgramUrl}?tableId=${newTable.id}&tableName=${encodeURIComponent(newTable.tableName)}`;

        // 生成二维码内容
        const qrCodeContent = tableInfoUrl;

        // 生成二维码图片并保存到服务器
        const qrCodeFilePath = path.join(__dirname, `../qr_codes/${newTable.id}.png`);
        await qrCode.toFile(qrCodeFilePath, qrCodeContent);

        // 将二维码文件路径保存到数据库中
        await newTable.update({ qrCode: qrCodeFilePath });

        res.status(201).json({ table: newTable, qrCode: qrCodeFilePath });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 删除餐桌信息（包括对应的二维码文件）
exports.deleteTable = async (req, res) => {
    try {
        const { tableId } = req.params;

        // 查找餐桌信息
        const table = await Table.findByPk(tableId);

        if (!table) {
            return res.status(404).json({ message: 'Table not found' });
        }

        // 删除数据库中的餐桌信息
        await table.destroy();

        // 删除对应的二维码文件
        if (table.qrCode) {
            fs.unlinkSync(table.qrCode);
        }

        res.json({ message: 'Table deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
