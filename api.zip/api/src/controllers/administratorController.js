const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Op } = require('sequelize');
const Administrator = require('../models/administrator');

//注册
exports.register = async (req, res) => {
    try {
        const { username, password, fullName, phoneNumber, email } = req.body;

        // 检查手机号是否已存在
        const phoneNumberExists = await Administrator.findOne({ where: { phoneNumber } });
        if (phoneNumberExists) {
            return res.status(400).json({ message: '此手机号已存在' });
        }

        // 检查邮箱是否已存在
        const emailExists = await Administrator.findOne({ where: { email } });
        if (emailExists) {
            return res.status(400).json({ message: '此邮箱已存在！' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const admin = await Administrator.create({ username, password: hashedPassword, fullName, phoneNumber, email });
        res.status(201).json({ message: '注册成功！' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

//管理员登录
exports.login = async (req, res) => {
    try {
        const { username, password } = req.body;
        const admin = await Administrator.findOne({ where: { username } });
        if (!admin) {
            return res.status(404).json({ message: '账号不存在！' });
        }
        const isPasswordValid = await bcrypt.compare(password, admin.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: '密码错误！' });
        }
        const token = jwt.sign({ adminId: admin.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token, admin });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getAdminById = async (req, res) => {
    try {
        const { adminId } = req.params;
        const admin = await Administrator.findByPk(adminId);
        if (!admin) {
            return res.status(404).json({ message: '账号不存在！' });
        }
        res.json(admin);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
//修改信息
exports.updateAdmin = async (req, res) => {
    try {
        const { adminId } = req.params;
        const { fullName, phoneNumber, email } = req.body;

        // 检查手机号是否已存在
        const phoneNumberExists = await Administrator.findOne({ where: { phoneNumber, id: { [Op.ne]: adminId } } });
        if (phoneNumberExists) {
            return res.status(400).json({ message: '手机号已存在！！' });
        }

        // 检查邮箱是否已存在
        const emailExists = await Administrator.findOne({ where: { email, id: { [Op.ne]: adminId } } });
        if (emailExists) {
            return res.status(400).json({ message: '邮箱已存在！' });
        }

        const [updated] = await Administrator.update({ fullName, phoneNumber, email }, { where: { id: adminId } });
        if (updated) {
            res.json({ message: '修改成功！' });
        } else {
            res.status(404).json({ message: '账号不存在！' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
//修改密码
exports.changePassword = async (req, res) => {
    try {
        const { adminId } = req.params;
        const { oldPassword, newPassword } = req.body;

        const admin = await Administrator.findByPk(adminId);
        if (!admin) {
            return res.status(404).json({ message: '账号不存在！' });
        }

        const isPasswordValid = await bcrypt.compare(oldPassword, admin.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: '密码错误！' });
        }

        // 加密新密码
        const hashedNewPassword = await bcrypt.hash(newPassword, 10);

        // 更新密码
        await admin.update({ password: hashedNewPassword });
        res.json({ message: '密码修改成功！' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
//删除管理员
exports.deleteAdmin = async (req, res) => {
    try {
        const { adminId } = req.params;

        // 查找要删除的管理员
        const admin = await Administrator.findByPk(adminId);
        if (!admin) {
            return res.status(404).json({ message: '账号不存在！' });
        }

        // 从数据库中删除管理员记录
        await admin.destroy();

        res.json({ message: '删除成功！' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};