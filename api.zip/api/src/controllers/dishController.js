const Dish = require('../models/Dish');
const DishPortion = require('../models/DishPortion');

// 获取所有菜品
exports.getAllDishes = async (req, res) => {
    try {
        const dishes = await Dish.findAll();
        res.json(dishes);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 根据分类名获取所有菜品
exports.getDishesByCategory = async (req, res) => {
    try {
        const { categoryName } = req.params;
        const dishes = await Dish.findAll({ where: { CategoryName: categoryName } });
        res.json(dishes);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 修改菜品
exports.updateDish = async (req, res) => {
    try {
        const { dishId } = req.params;
        const { DishName, BasePrice, DishImage, MerchantNote, StockQuantity, IsSignatureDish } = req.body;

        const updated = await Dish.update(
            { DishName, BasePrice, DishImage, MerchantNote, StockQuantity, IsSignatureDish },
            { where: { id: dishId } }
        );

        if (updated[0] === 1) {
            res.json({ message: '修改成功！' });
        } else {
            res.status(404).json({ message: 'Dish not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 删除菜品
exports.deleteDish = async (req, res) => {
    try {
        const { dishId } = req.params;

        // 检查该菜品下是否存在份量选择
        const portions = await DishPortion.findAll({ where: { dishId } });
        if (portions.length > 0) {
            // 存在份量选择，先删除这些份量选择
            await DishPortion.destroy({ where: { dishId } });
        }

        // 删除菜品
        const deletedCount = await Dish.destroy({ where: { id: dishId } });

        if (deletedCount === 1) {
            res.json({ message: '删除成功！' });
        } else {
            res.status(404).json({ message: 'Dish not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 增加菜品
exports.createDish = async (req, res) => {
    try {
        const { CategoryName, DishName, BasePrice, DishImage, MerchantNote, StockQuantity, IsSignatureDish } = req.body;

        // 创建菜品
        const newDish = await Dish.create({
            CategoryName,
            DishName,
            BasePrice,
            DishImage,
            MerchantNote,
            StockQuantity,
            IsSignatureDish
        });

        res.status(201).json(newDish);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
// 获取所有爆款推荐菜品
exports.getPopularDishes = async (req, res) => {
    try {
        const popularDishes = await Dish.findAll({ where: { IsSignatureDish: true } });
        res.json(popularDishes);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
