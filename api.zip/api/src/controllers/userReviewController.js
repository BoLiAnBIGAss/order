const UserReview = require('../models/UserReview');
const sequelize = require("../config/database");
const Dish = require('../models/Dish');
// 根据菜品查看评论并按评分从高到低展示
exports.getReviewsByDish = async (req, res) => {
    try {
        const { dishId } = req.params;

        // 查询特定菜品的所有评价，并按评分从高到低排序
        const reviews = await UserReview.findAll({
            where: { DishID: dishId },
            order: [['rating', 'DESC']]
        });

        res.json(reviews);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 创建用户评价
exports.createReview = async (req, res) => {
    try {
        const { CustomerID, DishID, commentText, rating } = req.body;

        // 创建用户评价
        const newReview = await UserReview.create({ CustomerID, DishID, commentText, rating });

        // 计算特定菜品的平均评分
        const averageRating = await UserReview.findOne({
            attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avgRating']],
            where: { DishID }
        });

        // 更新菜品的平均评分
        await Dish.update({ UserRating: averageRating.avgRating }, { where: { id: DishID } });

        res.status(201).json(newReview);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};