const DishPortion = require('../models/DishPortion');

// 根据菜品获取所有的份量选择
exports.getDishPortionsByDish = async (req, res) => {
    try {
        const { dishName } = req.params;
        const portions = await DishPortion.findAll({ where: { dishName } });
        res.json(portions);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 根据菜品增加份量选择
exports.createDishPortion = async (req, res) => {
    try {
        const { dishName, PortionName, PriceDelta } = req.body;

        // 创建份量选择
        const newPortion = await DishPortion.create({ dishName, PortionName, PriceDelta });

        res.status(201).json(newPortion);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 删除份量选择
exports.deleteDishPortion = async (req, res) => {
    try {
        const { portionId } = req.params;

        // 删除份量选择
        const deletedCount = await DishPortion.destroy({ where: { id: portionId } });

        if (deletedCount === 1) {
            res.json({ message: 'Dish Portion deleted successfully' });
        } else {
            res.status(404).json({ message: 'Dish Portion not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};