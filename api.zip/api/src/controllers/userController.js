const jwt = require('jsonwebtoken');
const User = require('../models/user');
//const defaultAvatarUrl = '../public/images/default-avatar.png'; // 默认头像URL

//登录-注册
exports.registerOrLogin = async (req, res) => {
    try {
        const { phoneNumber } = req.body;
        let user = await User.findOne({ where: { phoneNumber } });

        if (!user) {
            // 如果用户不存在,则自动创建新用户
            const defaultName = `顾客${phoneNumber}`;
            //const defaultAvatarUrl = '../images/default-avatar.png'; // 默认头像URL
            user = await User.create({ phoneNumber, CustomerName: defaultName });
        }

        // 生成JWT令牌
        const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token, user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getUserById = async (req, res) => {
    try {
        const { userId } = req.params;
        const user = await User.findByPk(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(user);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

//修改个人资料
exports.updateUser = async (req, res) => {
    try {
        const { userId } = req.params;
        const { name, avatarUrl } = req.body;
        const user = await User.findByPk(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // 更新用户信息
        await user.update({ name, avatarUrl });
        res.json({ message: '修改成功！' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
