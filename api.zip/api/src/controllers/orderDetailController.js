// controllers/orderDetailController.js

const OrderDetail = require('../models/OrderDetail');

// 生成订单详情
exports.createOrderDetail = async (req, res) => {
    try {
        const { orderId, orderDetails } = req.body;

        // 创建订单详情
        const createdOrderDetails = await Promise.all(orderDetails.map(async detail => {
            const { dishId, quantity, unitPrice } = detail;
            return await OrderDetail.create({ orderId, dishId, quantity, unitPrice });
        }));

        res.status(201).json(createdOrderDetails);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 删除订单详情
exports.deleteOrderDetail = async (req, res) => {
    try {
        const { orderDetailId } = req.params;

        // 删除订单详情
        const deletedCount = await OrderDetail.destroy({ where: { id: orderDetailId } });

        if (deletedCount === 1) {
            res.json({ message: 'Order Detail deleted successfully' });
        } else {
            res.status(404).json({ message: 'Order Detail not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
