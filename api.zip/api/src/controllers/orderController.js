// controllers/orderController.js

const Order = require('../models/Order');
const OrderDetail = require('../models/OrderDetail');

// 生成订单
exports.createOrder = async (req, res) => {
    try {
        const { phoneNumber, tableName, isTakeaway, totalAmount, orderStatus } = req.body;

        // 创建订单
        const newOrder = await Order.create({ phoneNumber, tableName, isTakeaway, totalAmount, orderStatus });

        res.status(201).json(newOrder);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 根据手机号按时间倒序查询所有订单
exports.getOrdersByPhoneNumber = async (req, res) => {
    try {
        const { phoneNumber } = req.params;

        // 查询订单
        const orders = await Order.findAll({ where: { phoneNumber }, order: [['orderTime', 'DESC']] });

        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 删除订单
exports.deleteOrder = async (req, res) => {
    try {
        const { orderId } = req.params;

        // 删除订单详情
        await OrderDetail.destroy({ where: { orderId } });

        // 删除订单
        const deletedCount = await Order.destroy({ where: { id: orderId } });

        if (deletedCount === 1) {
            res.json({ message: 'Order deleted successfully' });
        } else {
            res.status(404).json({ message: 'Order not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 按时间倒序查看所有订单
exports.getAllOrders = async (req, res) => {
    try {
        // 查询所有订单并按时间倒序排序
        const orders = await Order.findAll({ order: [['orderTime', 'DESC']] });

        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// 修改订单状态
exports.updateOrderStatus = async (req, res) => {
    try {
        const { orderId } = req.params;
        const { orderStatus } = req.body;

        // 更新订单状态
        const [updated] = await Order.update({ orderStatus }, { where: { id: orderId } });

        if (updated) {
            res.json({ message: 'Order status updated successfully' });
        } else {
            res.status(404).json({ message: 'Order not found' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
