const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();
const sequelize = require('./config/database');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use(morgan('dev'));



const userRoutes = require('./routes/userRoutes');
const dishRoutes = require('./routes/dishRoutes');
const adminRoutes = require('./routes/adminRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const dishPortionRoutes = require('./routes/dishPortionRoutes');
const orderRoutes = require('./routes/orderRoutes');
const orderDetailRoutes = require('./routes/orderDetailRoutes');
const userReviewRoutes = require('./routes/userReviewRoutes');
const tableRoutes = require('./routes/tableRoutes');


app.use('/api/v1/users', userRoutes);
app.use('/api/v1/dishes', dishRoutes);
app.use('/api/v1/admins', adminRoutes);
app.use('/api/v1/categories', categoryRoutes);
app.use('/api/v1/dish-portions', dishPortionRoutes);
app.use('/api/v1/orders', orderRoutes);
app.use('/api/v1/order-details', orderDetailRoutes);
app.use('/api/v1/tables', tableRoutes);
app.use('/api/v1/user-reviews', userReviewRoutes);





app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

module.exports = app;

