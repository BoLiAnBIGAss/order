const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const defaultAvatarUrl = '../public/images/default-avatar.png'; // 默认头像URL

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    phoneNumber: {
        type: DataTypes.STRING(20),
        allowNull: false,
        unique: true
    },
    CustomerName: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    AvatarURL: {
        type: DataTypes.STRING(255),
        allowNull: false,
        defaultValue: defaultAvatarUrl
    }
}, {
    tableName: 'Customers',
    timestamps: false
});

module.exports = User;
