const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const DishCategory = require('./DishCategory');

const Dish = sequelize.define('Dish', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    CategoryName: {
        type: DataTypes.STRING(50),
        allowNull: false,
        references: {
            model: DishCategory,
            key: 'CategoryName'
        }
    },
    DishName: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    BasePrice: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    DishImage: {
        type: DataTypes.BLOB('long'),
        allowNull: false
    },
    MerchantNote: {
        type: DataTypes.TEXT
    },
    StockQuantity: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    SalesCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
    },
    UserRating: {
        type: DataTypes.DECIMAL(3, 1),
        allowNull: false,
        defaultValue: 0
    },
    IsSignatureDish: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
    }
}, {
    tableName: 'Dishes',
    timestamps: false
});

Dish.belongsTo(DishCategory, { foreignKey: 'CategoryName', targetKey: 'CategoryName' });

module.exports = Dish;
