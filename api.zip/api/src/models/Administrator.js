const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Administrator = sequelize.define('Administrator', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    Username: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    PasswordHash: {
        type: DataTypes.STRING(128),
        allowNull: false
    },
    FullName: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    PhoneNumber: {
        type: DataTypes.STRING(20),
        allowNull: false,
        unique: true
    },
    Email: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true
    }
}, {
    tableName: 'Administrators',
    timestamps: false
});

module.exports = Administrator;
