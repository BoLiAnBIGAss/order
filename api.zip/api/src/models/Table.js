const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Table = sequelize.define('Table', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    tableName: {
        type: DataTypes.STRING(20),
        allowNull: false,
        unique: true
    },
    qrCode: {
        type: DataTypes.STRING(255),
        defaultValue: null
    }
}, {
    tableName: 'Tables',
    timestamps: false
});

module.exports = Table;
