const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Customer = require('./user');
const Table = require('./Table');

const Order = sequelize.define('Order', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    phoneNumber: {
        type: DataTypes.STRING(20),
        allowNull: false,
        references: {
            model: Customer,
            key: 'phoneNumber'
        }
    },
    tableName: {
        type: DataTypes.STRING(20),
        allowNull: false,
        references: {
            model: Table,
            key: 'tableName'
        }
    },
    orderTime: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    isTakeaway: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    totalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    orderStatus: {
        type: DataTypes.STRING(20),
        allowNull: false,
        defaultValue: 'error'
    }
}, {
    tableName: 'Orders',
    timestamps: false
});

Order.belongsTo(Customer, { foreignKey: 'phoneNumber', targetKey: 'phoneNumber' });
Order.belongsTo(Table, { foreignKey: 'tableName', targetKey: 'tableName' });

module.exports = Order;
