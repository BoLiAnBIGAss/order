const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Dish = require('./Dish');

const DishPortion = sequelize.define('DishPortion', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    DishName: {
        type: DataTypes.STRING(50),
        allowNull: false,
        references: {
            model: Dish,
            key: 'DishName'
        }
    },
    PortionName: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    PriceDelta: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    tableName: 'DishPortions',
    timestamps: false
});

DishPortion.belongsTo(Dish, { foreignKey: 'DishName', targetKey: 'DishName' });

module.exports = DishPortion;
