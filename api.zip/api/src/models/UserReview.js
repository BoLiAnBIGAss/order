const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Customer = require('./user');
const Dish = require('./Dish');

const UserReview = sequelize.define('UserReview', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    CustomerID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Customer,
            key: 'id'
        }
    },
    DishID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Dish,
            key: 'id'
        }
    },
    commentText: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    rating: {
        type: DataTypes.DECIMAL(3, 1),
        allowNull: false
    }
}, {
    tableName: 'UserReviews',
    timestamps: false,
    indexes: [
        {
            unique: true,
            fields: ['customerId', 'dishId']
        }
    ]
});

UserReview.belongsTo(Customer, { foreignKey: 'customerId' });
UserReview.belongsTo(Dish, { foreignKey: 'dishId' });

module.exports = UserReview;
