const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DishCategory = sequelize.define('DishCategory', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    CategoryName: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    }
}, {
    tableName: 'DishCategories',
    timestamps: false
});

module.exports = DishCategory;
