在 WebStorm 中创建一个新项目
选择 "Create New Project"
选择项目位置
不选择任何初始化模板
初始化 Node.js 项目
在项目根目录下运行 npm init -y 创建 package.json 文件
安装必要的依赖
运行 npm install express sequelize mysql2 body-parser cors morgan jsonwebtoken 安装依赖包
创建项目文件夹结构
在项目根目录下创建 src 文件夹
在 src 下创建 config、controllers、middlewares、models、routes、utils 文件夹
在项目根目录下创建 tests 文件夹,并在其中创建 controllers、models、routes 文件夹
创建入口文件 app.js
在 src 文件夹下创建 app.js 文件
在 app.js 中导入 Express 并创建应用程序实例
配置中间件,如 body-parser、cors、morgan 等
导入路由并挂载到应用程序实例上
配置数据库连接
在 src/config 文件夹下创建 database.js 文件
在 database.js 中配置 Sequelize 连接到 MySQL 数据库
创建模型文件
在 src/models 文件夹下创建对应的模型文件,如 user.js、dish.js 等
在模型文件中定义数据库表结构和关联关系
创建控制器文件
在 src/controllers 文件夹下创建对应的控制器文件,如 userController.js、dishController.js 等
在控制器文件中实现业务逻辑,如用户注册、获取菜品列表等

创建路由文件
在 src/routes 文件夹下创建对应的路由文件,如 userRoutes.js、dishRoutes.js 等
在路由文件中导入 Express 路由器和对应的控制器
定义路由路径和映射到对应的控制器方法
例如:
// userRoutes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.post('/register', userController.register);
router.post('/login', userController.login);
router.get('/:userId', userController.getUserById);
router.put('/:userId', userController.updateUser);

module.exports = router;
集成路由到应用程序
在 app.js 中导入路由文件
使用 app.use('/api/v1/users', userRoutes) 这种方式挂载路由
对于需要身份验证的路由,可以使用中间件进行保护,例如:
const authMiddleware = require('./middlewares/auth');

app.use('/api/v1/protected', authMiddleware, protectedRoutes);
创建中间件文件(可选)
在 src/middlewares 文件夹下创建中间件文件,如 auth.js
在中间件文件中实现身份验证、授权等逻辑
例如,在 auth.js 中使用 JWT 进行身份验证:
const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
const token = req.headers.authorization?.split(' ')[1];
if (!token) {
return res.status(401).json({ message: 'Authorization token missing' });
}

try {
const decoded = jwt.verify(token, process.env.JWT_SECRET);
req.user = decoded;
next();
} catch (err) {
return res.status(403).json({ message: 'Invalid or expired token' });
}
};

module.exports = authMiddleware;
创建 .env 文件
在项目根目录下创建 .env 文件
在 .env 文件中定义环境变量,如数据库连接信息、JWT 密钥等
在代码中使用 process.env.VARIABLE_NAME 访问环境变量
创建 .gitignore 文件
在项目根目录下创建 .gitignore 文件
在 .gitignore 文件中列出需要忽略的文件和文件夹,如 node_modules、.env 等
编写单元测试
在 tests 文件夹下创建对应的测试文件
使用 Jest 或 Mocha 等测试框架编写单元测试
测试控制器、模型、路由等模块的功能

启动应用程序
在 package.json 的 scripts 部分添加启动脚本,如:
"scripts": {
"start": "node src/app.js",
"dev": "nodemon src/app.js",
"test": "jest --watchAll"
}
运行 npm run dev 启动应用程序在开发模式下运行,使用 nodemon 可以监视文件变化并自动重启应用程序
运行 npm start 启动应用程序在生产模式下运行
生成 API 文档
安装 Swagger 相关依赖包: npm install swagger-ui-express swagger-jsdoc
在 src 目录下创建 docs 文件夹,并在其中创建 swagger.js 文件
在 swagger.js 中配置 Swagger 选项和 API 定义,例如:
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerDefinition = {
openapi: '3.0.0',
info: {
title: 'Point Meal System API',
version: '1.0.0',
description: 'API documentation for Point Meal System'
},
servers: [
{
url: 'http://localhost:3000/api/v1'
}
]
};

const options = {
swaggerDefinition,
apis: ['./routes/*.js']
};

const swaggerSpec = swaggerJSDoc(options);

module.exports = swaggerSpec;
在 app.js 中导入 Swagger 中间件并挂载到应用程序上,例如:
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./docs/swagger');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
现在,你可以访问 http://localhost:3000/api-docs 查看 Swagger UI 并测试 API 接口
部署应用程序
使用 PM2 部署和管理 Node.js 应用程序
安装 PM2: npm install -g pm2
启动应用程序: pm2 start src/app.js
查看应用程序状态: pm2 status
重启应用程序: pm2 restart app
使用 Nginx 作为反向代理服务器
安装 Nginx
配置 Nginx 将请求代理到 Node.js 应用程序
配置 SSL/TLS 和其他安全设置(可选)