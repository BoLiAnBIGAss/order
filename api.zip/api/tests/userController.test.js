// tests/userController.test.js

const request = require('supertest');
const app = require('../src/app'); // 这里需要根据实际项目结构修改.

describe('User Controller', () => {
    it('should create a new user', async () => {
        const response = await request(app)
            .post('/api/v1/users/register-or-login')
            .send({ phoneNumber: '1234567893' });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('user');
        expect(response.body).toHaveProperty('token');
    });

    it('should get user by ID', async () => {
        const response = await request(app)
            .get('/api/v1/users/1');

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('phoneNumber');
        // Add more assertions as needed
    });

    // Add more test cases for other controller methods
});
